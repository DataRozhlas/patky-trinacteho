library(ggplot2)
library(lubridate)

shinyServer(function(input, output) {
        load(file="data/patky13.R")
        
        output$vysledek <- renderText({ 
                vybranePatky  <- patky13[patky13>=input$rozsah[1] & patky13<=input$rozsah[2]]
                length(vybranePatky)
        })
        
        output$graf <- renderPlot({ 
                vybranePatky  <- patky13[patky13>=input$rozsah[1] & patky13<=input$rozsah[2]]
                grafData  <- data.frame(table(year(vybranePatky)))
                p  <- qplot(Var1,
                      Freq,
                      data=grafData,
                      geom="bar",
                      stat="identity",
                      ylab="Počet pátků třináctého",
                      xlab="Rok",
                      asp=0.25,
                      ylim=c(0,3))
                p  <- p + theme(axis.text.x = element_text(angle = 90, vjust=0.5))
                print(p)
        })
        
        output$tabulka <- renderTable({ 
                vybranePatky  <- patky13[patky13>=input$rozsah[1] & patky13<=input$rozsah[2]]
                data.frame(datum=format(vybranePatky, "%A %d. %B %Y"))
        })
})

