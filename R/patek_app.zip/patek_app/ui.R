library(ggplot2)
library(lubridate)

shinyUI(fluidPage(
        
        title = "Kolik pátků třináctého jste už zažili?",
        
        titlePanel("Kolik pátků třináctého jste už zažili?"),
        
        h4("Nejdříve si vyberte začátek a konec období – například datum svého narození a dnešní den."),
        
        dateRangeInput(inputId= "rozsah",
                       label="Zvolte datum",
                       start="1978-06-29",
                       end=Sys.Date(),
                       min="1900-01-01",
                       max="2100-12-31",
                       format="dd.mm.yyyy",
                       language="cs",
                       weekstart=1,
                       separator="do"),        
        
        hr(),
        
        h4("Ve vámi vybraném období se vyskytlo"),
        
        h1(textOutput("vysledek")),
        
        h4("pátků třináctého."),
        
        hr(),
        
        h4("Kolik jich bylo v jednotlivých letech?"),
        
        plotOutput("graf"),
        
        hr(),
        
        h4("Všechny pátky třináctého ve vybraném období"),
        
        tableOutput("tabulka")
        
        
))
